docker stop arm666
docker container rm arm666
docker build -t armwars .
docker run -d -p 24311:80 -e HOSTIP=`ip addr | grep "100.100" | awk '{print$ 2}'` --name arm666 armwars
