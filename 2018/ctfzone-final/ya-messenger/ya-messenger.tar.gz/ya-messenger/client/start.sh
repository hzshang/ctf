docker build -t ya-messenger-client .
docker run -it --net=host --rm ya-messenger-client localhost:3001
